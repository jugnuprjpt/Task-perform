import React, { useEffect, useState } from 'react'
import axios from 'axios';
const Axios = () => {

    const [data, setData] = useState();

    useEffect (()=>{
        axios.get('https://dog.ceo/api/breeds/image/random')
        .then ((resp)=>{
            setData (resp.data.message);
        })
    },
    []);

  return (
    <>
     <img src={data} alt="" width={500} />
    </>
    )
}


export default Axios;