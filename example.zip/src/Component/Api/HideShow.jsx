import React, { useState } from 'react'

const HideShow = () => {

    const [Show , setShow] = useState(false)
  return (
    <>
       <button onClick={()=>setShow(true)}>Hide</button>
       <button onClick={()=>setShow(false)}>Show</button>
       <button onClick={()=>setShow(!Show)}>Toggle</button>
       {Show && <h1>Show, Hide & Toggle</h1> }
   </>
  )
}

export default HideShow