import React, { useEffect, useState } from 'react'

const Api = () => {

    const [data, setData] = useState(null);

    useEffect (()=>{
        fetch('https://dog.ceo/api/breeds/image/random')
        .then(response => response.json())
        .then((apiData)=> {
        setData(apiData.message);
    });
}, []);

  return (
    <>
      
       <img src={data} alt="" width={500}/>
    </>
  )
}

export default Api