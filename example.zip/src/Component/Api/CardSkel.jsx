import React from 'react'
import Skeleton, {SkeletonTheme} from 'react-loading-skeleton'

const CardSkel = () => {
  return (
    <>
        <div className="card">
          <Skeleton circle = {true} height={100} width={100} />
            <h3><Skeleton  /></h3>
            <h4><Skeleton /></h4>
            <h4><Skeleton /></h4>
        </div>  

   </>
  )
}

export default CardSkel