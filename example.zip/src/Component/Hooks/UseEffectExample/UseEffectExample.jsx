import React, { useEffect, useState } from 'react'

const UseEffectExample = () => {

    const [state, setState] = useState ('posts');
    const [count, setCount] = useState (0)
    const [items, setItems] = useState ([])

     useEffect(()=>{
       console.log ("componenetdidmount")
     },[])

     useEffect(()=>{

        fetch('https://jsonplaceholder.typicode.com/'+ state)
  .then(response => response.json())
  .then(json => setItems(json))

        console.log("componenetdidupdate")
        return ()=> {
            console.log('Unmount')
        }
      },[state])
  return (
    <div>
       <button onClick={()=>setCount(count+1)}>count{count}</button>
       <button onClick={()=>setState('posts')}>Posts</button>
       <button onClick={()=>setState('users')}>Users</button>
       <button onClick={()=>setState('comments')}>Comments</button>
       <h1>{state}</h1>
       <ul>
        {
            items && items.map(item=> {
                return <li key={item.id}>{item.id} &nbsp;{item.name} &nbsp; {item.body}</li>
               
                      
            })
        }
       </ul>
    </div>
  )
}

export default UseEffectExample