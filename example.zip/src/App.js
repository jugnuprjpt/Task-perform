import logo from './logo.svg';
import './App.css';
import Api from './Component/Api/Api';
import Axios from './Component/Api/Axios';
/* import Skel from './Component/Api/Skel'; */
import SliderComponent from './Component/Api/SliderComponent';
import UseEffectExample from './Component/Hooks/UseEffectExample/UseEffectExample';
/* import Login from './Component/Api/Login'; */
import HideShow from './Component/Api/HideShow';
function App() {
  return (
    <>
    {/*  <Api></Api>  */}
    {/* <Axios></Axios> */}
   {/*   <Skel></Skel>   */}
   {/* <UseEffectExample> </UseEffectExample> */}
   {/*  <SliderComponent></SliderComponent> */}
   {/* <Login></Login> */}
  {/*  <HideShow></HideShow> */}
   </>
  );
}

export default App;
