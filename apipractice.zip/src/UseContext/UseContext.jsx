import React from 'react'

const UseContext = () => {
  return (
    <>
        UseContext
    </>
  )
}

export default UseContext