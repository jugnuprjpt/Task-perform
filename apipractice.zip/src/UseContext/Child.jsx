import { useContext } from 'react'
import React from 'react'
import { GlobalInfo } from '../App'

const Child = () => {
    const {appColor} = useContext(GlobalInfo);
    console.log("appColor", appColor)
  return (
    <>

        <h1 style={{color:appColor}}>child componenet</h1>
        
    </>
  )
}

export default Child