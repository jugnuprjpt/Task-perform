import React from 'react'

const UseChild = (Learning, count) => {

    console.log ("dadasd")
  return (
    <>
      <h1>welcome</h1>
    </>
  )
}

export default UseChild