import React from 'react'
import { useCallback } from 'react';
import { useState } from 'react'
import UseChild from './UseChild';

const UseCallback = () => {

    const [add, setAdd] = useState (0);
    const [count, setCount] = useState (0);

    const Learning = useCallback ( ()=>{

    }

    )

     
  return (
    <>
    <UseChild Learning = {Learning} count={count}/>
        <h1>Example of Usecallback</h1>
        <span>{add}</span>
        <button onClick={()=> setAdd (add +1)}>click-here</button>
        <h1>{count}</h1>
        <button onClick={()=> setCount (count+2)}>second-click</button>
    </>
  )
}

export default UseCallback