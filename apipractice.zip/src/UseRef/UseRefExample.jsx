import React from 'react'
import { useState } from 'react'
import { useRef } from 'react';


function UseRefExample  ()  {
  const refElement = useRef(""); 
  const [name, setName] = useState("jugnu");
  
  console.log(refElement) 

function Reset() {
    setName("")
    refElement.current.focus()

}
function handleInput() {
  refElement.current.style.color="blue"
  refElement.current.value="pihu"
}

  return (
    <>
       <h1>Learning useref</h1>
       <input ref={refElement} type="text" value={name} onChange={(e)=>setName(e.target.value)}></input>
       <button onClick={Reset}>Reset</button>
       <button onClick={handleInput}>handleinput</button>
   </>
  )
}

export default UseRefExample