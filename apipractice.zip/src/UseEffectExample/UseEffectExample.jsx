import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'

const UseEffectExample = () => {
    const [num , setNum] = useState(0)
    const [numo , setNumo] = useState(0)

    useEffect(()=>{
        alert("just-boom");
    },[num])
  return (
    <>
 
   <button onClick={(()=>{
    setNum(num+1);
   })}
   >click me{num}</button>
   <br />
   <button onClick={(()=>{
    setNumo(numo+1);
   })}
   >click me{numo}</button>
   </>
  )
}

export default UseEffectExample;