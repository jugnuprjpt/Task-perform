import React from 'react'
import { useEffect } from 'react';
import { useState } from 'react'

const UseEffectExampleOne = () => {
    const [change, setChange] = useState (0);
    const [number, setNumber] = useState (5)

    /* ------udemy------- */

    const [ajay, setAjay] = useState('posts')
    const [item, setItem] = useState([])

    useEffect (()=>{
        fetch(`https://jsonplaceholder.typicode.com/${ajay}`)
        .then(response => response.json())
        .then(json => setItem(json))

    },[ajay])

    useEffect (()=>{
        document.title = `you clicked number {change}`;
        console.log("title is changed")
    })


    const handleSubmit = () => {
        setChange (change+1);

    }
    const handleDone = () => {
        setNumber (number+1);

    }
  return (
    <>
        <h1>Hello world its number{number}</h1>
        <h2>Hello world its number{change}</h2>
        <button onClick={handleSubmit}>Click-me</button>
        <button onClick={handleDone}>state changed</button>

        {/* -------udemy----- */}

        <button onClick={()=>setAjay('post')}>Posts</button>
        <button onClick={()=>setAjay('user')}>Users</button>
        <button onClick={()=>setAjay('commet')}>Commets</button>
        <h1>{ajay}</h1>
        {item.map (item => {
            return <pre>{JSON.stringify(item)}</pre>
        })}



    </>
  )
}

export default UseEffectExampleOne