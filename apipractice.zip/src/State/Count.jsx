import React from "react";
import { useState } from "react";

const Count = () => {
  const [count, setCount] = useState(0);

  function increment() {
    setCount((preCount) => preCount + 1);
  }
  function decrement() {
    setCount((preCount) => preCount - 1);
  }

  return (
    <>
      <button onClick={decrement}>-</button> &nbsp;
      <span>{count}</span> &nbsp;
      <button onClick={increment}>+</button>
    </>
  );
};

export default Count;
