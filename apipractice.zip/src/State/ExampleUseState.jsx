import React from "react";
import { useState } from "react";

const ExampleUseState = () => {
  const [data, setData] = useState("jugnu");

  function updateData() {
    setData("pihu");
  }

  return (
    <>
      <h1>{data}</h1>
      <button onClick={updateData}>update</button>
    </>
  );
};

export default ExampleUseState;
