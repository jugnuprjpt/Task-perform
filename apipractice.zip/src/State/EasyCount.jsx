import React from 'react'
import { useState } from 'react'

function EasyCount () {
    const [Count, setCount] = useState(5);

    const increment = () => {    
        setCount(Count+1);

    }
    const decrement = () =>{
        setCount(Count-1);

    }
  return (
    <>
        <h1>Here shown counting number</h1>
        <p>{Count}</p>
        <button onClick={decrement}>-</button>
        
        <button onClick={increment}>+</button>
    </>
  )
}

export default EasyCount