import React, { useState } from 'react'
import { useMemo } from 'react';

const UseMemo = () => {

    const [add, setAdd] = useState(0);
    const [minus, setMinus] = useState(100);


    const mulipication = useMemo (

        function multiply() {
            console.log("......")
            return add*10;
        },[add]);

  return (
    <>
    {mulipication}
    <button onClick={()=>setAdd(add+1)}>Addition</button>
    <span>{add}</span>
    <br />
    <button onClick={()=>setMinus(minus-1)}>Subtracion</button>
    <span>{minus}</span>
    </>
  )
}

export default UseMemo