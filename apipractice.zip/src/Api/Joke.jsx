import { computeHeadingLevel } from '@testing-library/react';
import axios from 'axios'
import React from 'react'
import { useState } from 'react'

const Joke = () => {

  const [jugnu, setJugnu] = useState ();

  const getJoke = () =>{
    axios.get ("https://jsonplaceholder.typicode.com/users")
    .then((Response)=>{

      setJugnu(Response.data)

    })
  }
  return (
    <>
       <button onClick={getJoke}>Joke-click-me</button>
       {jugnu && jugnu.map((i)=>(

        <p>{i.name}</p>
        
      /*   console.log(i.name) */

       ))}
    </>
  )
}
export default Joke