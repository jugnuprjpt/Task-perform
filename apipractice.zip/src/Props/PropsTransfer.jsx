import React from 'react'
import PropExample from './PropExample'
/* import img from "../logo192.png"  */


const PropsTransfer = () => {
  return (
    <>
      {/* <PropExample name = {"jugnu"}  /> */}
      <div className="container">
        <div className="row">
          <div className="col-md-3 ">
          <PropExample title = {"sabu"} Desciption = {"all in one"} btn = {"abc"} />
      <PropExample title = {"fd"} Desciption = {"all in one"} btn = {"abc"} />
      <PropExample title = {"ds"} Desciption = {"all in one"} btn = {"abc"}  />
      <PropExample title = {"ssadabu"} Desciption = {"all in one"} btn = {"abc"}  />

          </div>
        </div>
      </div>
      
     {/*  <img src="../logo192.png" alt="" /> */}
    
    
    </>
  )
}

export default PropsTransfer