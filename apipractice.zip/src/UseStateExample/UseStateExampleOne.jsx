import React, { useState } from 'react'

const UseStateExampleOne = () => {

    const [state, setState] = useState (0);
    const handleSubmit = () =>{
        setState (state + 1);


    }
  return (
    <>
        <h1>Hello worls here present {state} </h1>
        <button onClick={handleSubmit}>Click-me</button>
    </>
  )
}

export default UseStateExampleOne