import { createContext, useContext, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import Api from './Api/Api';
import News from './Api/News';
import Joke from './Api/Joke';
import Nav from './Api/Nav';
import ExampleUseState from './State/ExampleUseState';
import ClickUseState from './State/ClickUseState';
import Count from './State/Count';
import EasyCount from './State/EasyCount';
import PropsTransfer from './Props/PropsTransfer';
import UseStateExample from './UseStateExample/UseStateExample';
import UseEffectExample from './UseEffectExample/UseEffectExample'
import UseStateExampleOne from './UseStateExample/UseStateExampleOne';
import UseEffectExampleOne from './UseEffectExample/UseEffectExampleOne';
import UseMemo from './UseMemo/UseMemo';
import UseCallback from './UseCallback/UseCallback';
import UseRefExample from './UseRef/UseRefExample';
/* import Child from './UseContext/Child'; */



/* export const GlobalInfo = createContext(); */



function App() {

  /* const [color, setColor] = useState('red'); */
  return (
    <>
   {/*  <News></News> */}
   {/*  <GlobalInfo.Provider value={{appColor:color}}> */}
      <Joke></Joke>
      {/* <br/>
      <hr/>  */}
     {/* <Nav></Nav> 
     <br/>
     <hr/>
      <ExampleUseState></ExampleUseState>
      <br/>
      <hr/>
      <ClickUseState></ClickUseState>
      <br/>
      <br/>
      <hr/>
      <Count></Count>
      <br/>
      <br/>
      <hr/>
      <EasyCount></EasyCount>
      <br/>
      <br/>
      <hr/>
      <PropsTransfer></PropsTransfer>
      <br/>
      <br/>
      <hr/>
      <UseStateExample></UseStateExample>
      <br/>
      <br/>
      <hr/>
      <UseEffectExample></UseEffectExample>
      <br/>
      <br/>
      <hr/>  */}
      {/* <UseStateExampleOne></UseStateExampleOne>
      <UseEffectExampleOne></UseEffectExampleOne>
      <UseContext></UseContext> */}

      {/* -------usecontext---- */}

     {/*  <h1>hello welcome</h1>
      <Child></Child>
      </GlobalInfo.Provider> */}
     
      {/* 
      <server-api></server-api> */}
     {/*  <Api></Api>    */}
     {/*  <News></News> */}
   {/*   <news></news> */}
  {/*  <UseMemo></UseMemo> */}
  {/*  <UseCallback></UseCallback>
   <UseRefExample></UseRefExample> */}
    </>
  );
}

export default App;
