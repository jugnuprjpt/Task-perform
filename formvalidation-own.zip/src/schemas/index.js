import * as Yup  from "yup";



const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/
export const signUpSchema = Yup.object({
    name : Yup.string().min(3).max(10).required("please enter your name"),
    email: Yup.string().email().required("please enter your emial id"),
    passward: Yup.string().min(6).required("please enter your passward"),
    confirm_passward:Yup.string().required().oneOf([Yup.ref("passward"), null, "passward must be match"]),
    phone: Yup.string().min(10).max(10).matches(phoneRegExp).required ('Phone number is not valid'),
    termsAndCondtions: Yup.boolean().oneOf(
        [true],
        "Please accept terms and conditons"
      ),
  
})