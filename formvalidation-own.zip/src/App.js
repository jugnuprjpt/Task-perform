import logo from './logo.svg';
import './App.css';
import FormValidation from './FormValidation/FormValidation';

function App() {
  return (
    <>
      <FormValidation></FormValidation>
    </>
  );
}

export default App;
