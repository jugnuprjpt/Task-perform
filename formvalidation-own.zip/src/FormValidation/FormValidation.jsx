import React from "react";
import { Formik } from "formik";
import { useFormik } from "formik";
import { signUpSchema } from "../schemas";

const initialValues = {
  name: "",
  email: "",
  passward: "",
  confirm_passward: "",
  phone:"",
  gender: "male",
  termsAndCondtions:""
};

const FormValidation = () => {
  const {values, errors, touched,handleChange ,handleBlur ,handleSubmit} = useFormik({
    initialValues: initialValues,
    validationSchema:signUpSchema,
    onSubmit: (values,action) => {
      console.log(
        "~ file: Registration.jsx ~ line 11 ~ Registration ~ values",
        values
      );
      action.resetForm();
    },
  });
   console.log(
    "~ file: Registration.jsx ~ line 11 ~ Registration ~ errors",
    errors
  ); 
  return (
    <>
      <br />
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name">Name:-</label>
          <input
            type="name"
            autoComplete="off"
            name="name"
            id="name"
            placeholder="Enter your name"
            value ={values.name}
            onChange ={handleChange}
            onBlur ={handleBlur}
          />
          {errors.name && touched.name ? (

            <p className="form-error">{errors.name}</p>
          ):null}
        </div>
        <br />
        <div>
          <label htmlFor="email">Email:-</label>
          <input type="email"  name="email"
            id="email"
            autoComplete="off"
            placeholder="enter your email"
            value ={values.email}
            onChange ={handleChange}
            onBlur ={handleBlur}
             />
              {errors.email && touched.email ? (

              <p className="form-error">{errors.email}</p>
              ):null}
        </div>
        <br />
        <div>
          <label htmlFor="passward">Passward:-</label>
          <input
            type="passward"
            name="passward"
            id="passward"
            autoComplete="off"
            placeholder="enter your passward"
            value ={values.passward}
            onChange ={handleChange}
            onBlur ={handleBlur}
          />
           {errors.passward && touched.passward ? (

<p className="form-error">{errors.passward}</p>
):null}
        </div>
        <br />
        <div>
          <label htmlFor="confrim_passward">Confirm-Passward:-</label>
          <input type="passward" 
           name="confirm_passward"
           id="confirm_passward"
           autoComplete="off"
           placeholder="enter your confirm_passward"
           value ={values.confirm_passward}
           onChange ={handleChange}
           onBlur ={handleBlur}
          />
           {errors.confirm_passward && touched.confirm_passward ? (

<p className="form-error">{errors.confirm_passward}</p>
):null}
        </div>
        <br />
        <div>
          <label htmlFor="mobile_number">Mobile-number:-</label>
          <input
                type="number"
                placeholder="Enter your mobile number"
                id="phone"
                name="phone"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.phone}
              />
          
         
           {errors.phone && touched.phone ? (

       <p className="form-error">{errors.phone}</p>
       ):null}
       
        </div>
        <br />

        <div className="form-group mt-2">
              <label>Gender</label>
              <div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="gender"
                    id="male"
                    value="male"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    checked={values.gender === "male"}
                  />
                  <label className="form-check-label" for="male">
                    Male
                  </label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="gender"
                    id="female"
                    value="female"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    checked={values.gender === "female"}
                  />
                  <label className="form-check-label" for="female">
                    Female
                  </label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="gender"
                    id="other"
                    value="other"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    checked={values.gender === "other"}
                  />
                  <label className="form-check-label" for="other">
                    Other
                  </label>
                </div>
              </div>
            </div>
        <div>
        <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="termsAndCondtions"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.termsAndCondtions}
                />
                <label className="form-check-label" htmlFor="termsAndCondtions">
                  Accept terms and conditions.
                </label>
              </div>
              {touched.termsAndCondtions &&
                errors.termsAndCondtions && (
                  <span className="field_error">
                    {errors.termsAndCondtions}
                  </span>
                )}
            <br />
          <button type="submit">Submit</button>
        </div>
      </form>
    </>
  );
};

export default FormValidation;
